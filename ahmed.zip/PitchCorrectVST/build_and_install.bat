@echo off
setlocal EnableDelayedExpansion
:: =====================================================================
:: PitchCorrectVST - Fully Automated Dependency & VST3 Installer
:: Builds the plugin from source and installs the VST3 directly into
:: the system VST3 folder that FL Studio scans by default.
:: =====================================================================
title PitchCorrect VST3 - Zero Dependency Auto-Installer
color 0B

echo =====================================================================
echo    PitchCorrect VST3 - Automated Setup ^& Installer for FL Studio
echo =====================================================================
echo.

:: ---------------------------------------------------------------------
:: 1. Force Administrator elevation (needed to write to Program Files
::    and to install build tools system-wide).
:: ---------------------------------------------------------------------
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [*] Requesting Administrator privileges...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs" >nul 2>&1
    exit /b
)

:: ---------------------------------------------------------------------
:: 2. Always work relative to THIS script's own folder, not a guessed
::    Downloads path. This is what actually makes "build and install"
::    work regardless of where the folder was extracted/moved to --
::    the previous version silently built the wrong (or a stale) copy
::    of the project if it existed under %USERPROFILE%\Downloads.
:: ---------------------------------------------------------------------
set "PROJECT_DIR=%~dp0"
if "%PROJECT_DIR:~-1%"=="\" set "PROJECT_DIR=%PROJECT_DIR:~0,-1%"
cd /d "%PROJECT_DIR%"

if not exist "%PROJECT_DIR%\CMakeLists.txt" (
    echo [X] ERROR: CMakeLists.txt not found next to this script.
    echo     Make sure build_and_install.bat stays inside the extracted
    echo     PitchCorrectVST folder ^(next to CMakeLists.txt and Source\^).
    pause
    exit /b 1
)

set "VST3_TARGET_DIR=%COMMONPROGRAMFILES%\VST3"

echo [*] Project folder : %PROJECT_DIR%
echo [*] Install target  : %VST3_TARGET_DIR%
echo.

:: ---------------------------------------------------------------------
:: 3. Auto-detect and auto-install missing build tools via winget.
::    Each tool is (re)checked with `where` immediately after install
::    and PATH is refreshed from the registry so the rest of THIS
::    session sees newly-installed tools without needing a reboot.
:: ---------------------------------------------------------------------
where winget >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] winget was not found on this system.
    echo     Install "App Installer" from the Microsoft Store, then re-run
    echo     this script. ^(winget ships with Windows 10 2004+ / Windows 11.^)
    pause
    exit /b 1
)

echo [*] Checking required build tools...

where git >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] Git not found. Installing via winget...
    winget install --id Git.Git -e --accept-source-agreements --accept-package-agreements
)
set "PATH=%PATH%;%ProgramFiles%\Git\cmd"

where cmake >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] CMake not found. Installing via winget...
    winget install --id Kitware.CMake -e --accept-source-agreements --accept-package-agreements
)
set "PATH=%PATH%;%ProgramFiles%\CMake\bin"

:: Check for an MSVC C++ toolchain (VS2022 Build Tools or full VS2022).
set "HAS_MSVC=0"
reg query "HKLM\SOFTWARE\Microsoft\VisualStudio\17.0" >nul 2>&1 && set "HAS_MSVC=1"
reg query "HKLM\SOFTWARE\WOW6432Node\Microsoft\VisualStudio\17.0" >nul 2>&1 && set "HAS_MSVC=1"
if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe" (
    for /f "usebackq tokens=*" %%i in (`"%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do (
        if not "%%i"=="" set "HAS_MSVC=1"
    )
)

if "%HAS_MSVC%"=="0" (
    echo [!] MSVC C++ Build Tools not found. Installing Visual Studio 2022
    echo     Build Tools ^(this step can take several minutes^)...
    winget install --id Microsoft.VisualStudio.2022.BuildTools -e --override "--quiet --wait --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended" --accept-source-agreements --accept-package-agreements
)

where git  >nul 2>&1 || (echo [X] ERROR: Git still not available after install. & pause & exit /b 1)
where cmake >nul 2>&1 || (echo [X] ERROR: CMake still not available after install. & pause & exit /b 1)

echo [+] All required build tools are ready.
echo.

:: ---------------------------------------------------------------------
:: 4. Clone JUCE if missing (or re-clone if a previous clone was left
::    incomplete, e.g. from an interrupted run).
:: ---------------------------------------------------------------------
if exist "JUCE" if not exist "JUCE\CMakeLists.txt" (
    echo [!] Found an incomplete JUCE checkout, removing it before re-cloning...
    rmdir /s /q "JUCE"
)

if not exist "JUCE" (
    echo [*] JUCE framework missing. Cloning from GitHub...
    git clone https://github.com/juce-framework/JUCE.git JUCE --depth 1 --branch 7.0.12
    if %errorLevel% neq 0 (
        echo [X] ERROR: Failed to clone JUCE. Check your internet connection.
        pause
        exit /b %errorLevel%
    )
    echo [+] JUCE cloned successfully!
    echo.
)

:: ---------------------------------------------------------------------
:: 5. Configure and build the VST3 (64-bit -- FL Studio on modern
::    Windows is 64-bit, and the plugin must match).
::    Only the VST3 target is built (not Standalone) to keep this fast;
::    JUCE's CMake support generates a "<Target>_VST3" build target.
::    If a stale build\ cache from a previous run is causing the
::    configure step to fail (e.g. a different generator/arch was used
::    last time), wipe it and retry once automatically.
:: ---------------------------------------------------------------------
echo [*] Generating build project files via CMake ^(x64^)...
cmake -B build -A x64 -DCMAKE_BUILD_TYPE=Release
if %errorLevel% neq 0 (
    echo [!] CMake configuration failed, clearing cache and retrying once...
    rmdir /s /q build 2>nul
    cmake -B build -A x64 -DCMAKE_BUILD_TYPE=Release
    if !errorLevel! neq 0 (
        echo [X] ERROR: CMake configuration failed.
        pause
        exit /b !errorLevel!
    )
)

echo [*] Compiling VST3 plugin... please wait, this can take a few minutes.
cmake --build build --config Release --target PitchCorrectVST_VST3 --parallel
if %errorLevel% neq 0 (
    echo [X] ERROR: Compilation failed. Scroll up for the compiler error.
    pause
    exit /b %errorLevel%
)
echo [+] Compilation successful!
echo.

:: ---------------------------------------------------------------------
:: 6. Install the built VST3 into FL Studio's default VST3 folder.
::    JUCE's COPY_PLUGIN_AFTER_BUILD already does this automatically as
::    part of the build step above; the block below is a safety net in
::    case that copy step was blocked (e.g. missing admin rights on a
::    previous run) and also gives explicit success/failure feedback.
:: ---------------------------------------------------------------------
echo [*] Verifying installed VST3 plugin...
if not exist "%VST3_TARGET_DIR%" mkdir "%VST3_TARGET_DIR%"

set "ARTIFACT_PATH=build\PitchCorrectVST_artefacts\Release\VST3"

if not exist "%ARTIFACT_PATH%\PitchCorrect.vst3" (
    echo [!] Expected artifact not found at the usual path, searching build\ ...
    for /f "delims=" %%f in ('dir /b /s /a:d "build\PitchCorrect.vst3" 2^>nul') do set "ARTIFACT_PATH=%%~dpf"
)

if exist "%ARTIFACT_PATH%\PitchCorrect.vst3" (
    xcopy "%ARTIFACT_PATH%\PitchCorrect.vst3" "%VST3_TARGET_DIR%\PitchCorrect.vst3\" /E /I /Y /Q >nul
) 

if exist "%VST3_TARGET_DIR%\PitchCorrect.vst3" (
    echo.
    echo =====================================================================
    echo [SUCCESS] PitchCorrect VST3 is installed and ready!
    echo [*] VST3 Path: %VST3_TARGET_DIR%\PitchCorrect.vst3
    echo.
    echo Next steps in FL Studio:
    echo   1. Open FL Studio.
    echo   2. Options -^> Manage Plugins.
    echo   3. Click "Find plugins" ^(or "Find installed plugins"^) to rescan.
    echo   4. PitchCorrect will appear under Effects -^> Manufacturer name.
    echo      ^(If FL Studio was already open, restart it so it picks up
    echo      the new plugin.^)
    echo =====================================================================
) else (
    echo.
    echo [X] ERROR: Could not find or install the compiled .vst3 bundle.
    echo     Expected it under: build\PitchCorrectVST_artefacts\Release\VST3\
    echo     Check the compiler output above for errors.
)

echo.
pause
