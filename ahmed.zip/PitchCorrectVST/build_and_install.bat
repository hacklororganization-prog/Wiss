@echo off
setlocal EnableDelayedExpansion
:: =====================================================================
:: PitchCorrectVST - Fully Automated Cleanup + Dependency + VST3
:: Installer (all-in-one)
:: 1) Optionally cleans up old leftover PitchCorrectVST copies/zips
::    under Downloads (asks for confirmation first, nothing is
::    touched without your Y).
:: 2) Builds the plugin from source and installs the VST3 directly
::    into the system VST3 folder that FL Studio scans by default.
:: Every network/build step below retries automatically and falls
:: back to alternate methods instead of giving up on the first error.
:: =====================================================================
title PitchCorrect VST3 - Zero Dependency Auto-Installer
color 0B

echo =====================================================================
echo    PitchCorrect VST3 - Automated Cleanup, Setup ^& Installer
echo =====================================================================
echo.

:: ---------------------------------------------------------------------
:: 1. Force Administrator elevation (needed to write to Program Files
::    and to install build tools system-wide).
:: ---------------------------------------------------------------------
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [*] Requesting Administrator privileges...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs" >nul 2>&1
    exit /b
)

:: ---------------------------------------------------------------------
:: 2. Always work relative to THIS script's own folder, not a guessed
::    Downloads path. This is what actually makes "build and install"
::    work regardless of where the folder was extracted/moved to.
:: ---------------------------------------------------------------------
set "PROJECT_DIR=%~dp0"
if "%PROJECT_DIR:~-1%"=="\" set "PROJECT_DIR=%PROJECT_DIR:~0,-1%"
cd /d "%PROJECT_DIR%"

:: ---------------------------------------------------------------------
:: 2b. Internet connectivity check, retried up to 10 times before
::     giving up. Nothing that needs the network is attempted until
::     this passes, so the script never dies with a confusing git/
::     winget error just because Wi-Fi hadn't reconnected yet.
:: ---------------------------------------------------------------------
set "NET_TRIES=0"
:CheckNet
set /a NET_TRIES+=1
ping -n 1 -w 3000 github.com >nul 2>&1
if %errorLevel% neq 0 (
    if %NET_TRIES% GEQ 10 (
        echo [X] ERROR: No internet connection after 10 attempts.
        echo     Connect to the internet and re-run this script.
        pause
        exit /b 1
    )
    echo [!] No internet connection yet ^(attempt %NET_TRIES%/10^), retrying in 5s...
    timeout /t 5 /nobreak >nul
    goto CheckNet
)

:: ---------------------------------------------------------------------
:: 3. Optional cleanup pass: find old leftover PitchCorrectVST project
::    folders / zip files under Downloads and offer to delete them.
::    This never touches anything outside Downloads, and nothing is
::    deleted without you typing Y. Skipping this is always safe.
:: ---------------------------------------------------------------------
call :Cleanup

if not exist "%PROJECT_DIR%\CMakeLists.txt" (
    echo [X] ERROR: CMakeLists.txt not found next to this script.
    echo     Make sure build_and_install.bat stays inside the extracted
    echo     PitchCorrectVST folder ^(next to CMakeLists.txt and Source\^).
    pause
    exit /b 1
)

set "VST3_TARGET_DIR=%COMMONPROGRAMFILES%\VST3"

echo [*] Project folder : %PROJECT_DIR%
echo [*] Install target  : %VST3_TARGET_DIR%
echo.

:: ---------------------------------------------------------------------
:: 4. Auto-detect and auto-install missing build tools via winget.
::    Each tool is (re)checked with `where` immediately after install
::    and PATH is refreshed so the rest of THIS session sees newly-
::    installed tools without needing a reboot.
:: ---------------------------------------------------------------------
where winget >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] winget was not found on this system.
    echo     Install "App Installer" from the Microsoft Store, then re-run
    echo     this script. ^(winget ships with Windows 10 2004+ / Windows 11.^)
    pause
    exit /b 1
)

echo [*] Checking required build tools...

where git >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] Git not found. Installing via winget...
    set "WG_TRIES=0"
    :InstallGitRetry
    set /a WG_TRIES+=1
    winget install --id Git.Git -e --accept-source-agreements --accept-package-agreements --force
    where git >nul 2>&1
    if !errorLevel! neq 0 if !WG_TRIES! LSS 3 (
        echo [!] Git install attempt !WG_TRIES!/3 did not stick, retrying in 5s...
        timeout /t 5 /nobreak >nul
        goto InstallGitRetry
    )
)
set "PATH=%PATH%;%ProgramFiles%\Git\cmd"

where cmake >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] CMake not found. Installing via winget...
    set "WG_TRIES=0"
    :InstallCMakeRetry
    set /a WG_TRIES+=1
    winget install --id Kitware.CMake -e --accept-source-agreements --accept-package-agreements --force
    where cmake >nul 2>&1
    if !errorLevel! neq 0 if !WG_TRIES! LSS 3 (
        echo [!] CMake install attempt !WG_TRIES!/3 did not stick, retrying in 5s...
        timeout /t 5 /nobreak >nul
        goto InstallCMakeRetry
    )
)
set "PATH=%PATH%;%ProgramFiles%\CMake\bin"

:: Check for an MSVC C++ toolchain (VS2022 Build Tools or full VS2022).
set "HAS_MSVC=0"
reg query "HKLM\SOFTWARE\Microsoft\VisualStudio\17.0" >nul 2>&1 && set "HAS_MSVC=1"
reg query "HKLM\SOFTWARE\WOW6432Node\Microsoft\VisualStudio\17.0" >nul 2>&1 && set "HAS_MSVC=1"
if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe" (
    for /f "usebackq tokens=*" %%i in (`"%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do (
        if not "%%i"=="" set "HAS_MSVC=1"
    )
)

if "%HAS_MSVC%"=="0" (
    echo [!] MSVC C++ Build Tools not found. Installing Visual Studio 2022
    echo     Build Tools ^(this step can take several minutes^)...
    winget install --id Microsoft.VisualStudio.2022.BuildTools -e --override "--quiet --wait --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended" --accept-source-agreements --accept-package-agreements
)

where git  >nul 2>&1 || (echo [X] ERROR: Git still not available after install. & pause & exit /b 1)
where cmake >nul 2>&1 || (echo [X] ERROR: CMake still not available after install. & pause & exit /b 1)

echo [+] All required build tools are ready.
echo.

:: ---------------------------------------------------------------------
:: 5. Clone JUCE if missing (or re-clone if a previous clone was left
::    incomplete, e.g. from an interrupted run).
:: ---------------------------------------------------------------------
if exist "JUCE" if not exist "JUCE\CMakeLists.txt" (
    echo [!] Found an incomplete JUCE checkout, removing it before re-cloning...
    call :ForceRemoveDir "JUCE"
)

if not exist "JUCE" (
    echo [*] JUCE framework missing. Downloading ^(this step will not give up^)...
    call :GetJUCE
    if not exist "JUCE\CMakeLists.txt" (
        echo [X] ERROR: Could not obtain JUCE after every retry and fallback method.
        echo     This almost always means the network/firewall is blocking both
        echo     git:// / https:// GitHub access. Try a different network ^(e.g.
        echo     phone hotspot^), then re-run this script.
        pause
        exit /b 1
    )
    echo [+] JUCE ready!
    echo.
)
goto AfterJUCE

:: -----------------------------------------------------------------
:: :GetJUCE - guarantees a usable JUCE checkout or exhausts every
:: option trying. Strategy, in order, each with its own retries:
::   A) git clone --depth 1 --branch 8.0.15   (up to 5 attempts)
::   B) git clone with no --depth (in case shallow clone is what's
::      blocked by a proxy)                    (up to 3 attempts)
::   C) Direct zip download of the tag via GitHub, then expand it
::      (up to 5 attempts)
:: Any partial/corrupt leftover from a failed attempt is wiped before
:: the next attempt so nothing "half downloaded" can block a retry.
:: -----------------------------------------------------------------
:GetJUCE
set "JUCE_TRIES=0"
:JuceGitShallow
set /a JUCE_TRIES+=1
if exist "JUCE" call :ForceRemoveDir "JUCE"
echo [*] [git shallow] attempt !JUCE_TRIES!/5...
git clone https://github.com/juce-framework/JUCE.git JUCE --depth 1 --branch 8.0.15
if exist "JUCE\CMakeLists.txt" goto :eof
if !JUCE_TRIES! LSS 5 (
    echo [!] Attempt failed, retrying in 8s...
    timeout /t 8 /nobreak >nul
    goto JuceGitShallow
)

set "JUCE_TRIES=0"
:JuceGitFull
set /a JUCE_TRIES+=1
if exist "JUCE" call :ForceRemoveDir "JUCE"
echo [*] [git full clone] attempt !JUCE_TRIES!/3 ^(fallback^)...
git clone https://github.com/juce-framework/JUCE.git JUCE --branch 8.0.15
if exist "JUCE\CMakeLists.txt" goto :eof
if !JUCE_TRIES! LSS 3 (
    echo [!] Attempt failed, retrying in 8s...
    timeout /t 8 /nobreak >nul
    goto JuceGitFull
)

set "JUCE_TRIES=0"
:JuceZip
set /a JUCE_TRIES+=1
if exist "JUCE" call :ForceRemoveDir "JUCE"
if exist "juce_tmp.zip" del /f /q "juce_tmp.zip" >nul 2>&1
echo [*] [zip download] attempt !JUCE_TRIES!/5 ^(fallback, no git needed^)...
powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; try { Invoke-WebRequest -Uri 'https://github.com/juce-framework/JUCE/archive/refs/tags/8.0.15.zip' -OutFile 'juce_tmp.zip' -TimeoutSec 120 } catch { exit 1 }"
if exist "juce_tmp.zip" (
    powershell -NoProfile -Command "try { Expand-Archive -Path 'juce_tmp.zip' -DestinationPath '.' -Force } catch { exit 1 }"
    if exist "JUCE-8.0.15" (
        move /y "JUCE-8.0.15" "JUCE" >nul
    )
    del /f /q "juce_tmp.zip" >nul 2>&1
)
if exist "JUCE\CMakeLists.txt" goto :eof
if !JUCE_TRIES! LSS 5 (
    echo [!] Attempt failed, retrying in 10s...
    timeout /t 10 /nobreak >nul
    goto JuceZip
)
goto :eof

:: -----------------------------------------------------------------
:: :ForceRemoveDir <path> - deletes a folder even when Windows says
:: it's "in use" (common with antivirus scanning new files, or
:: Explorer/an editor holding a handle open). Clears read-only/
:: hidden/system attributes first, then retries the delete a few
:: times with short pauses instead of failing on the first try.
:: -----------------------------------------------------------------
:ForceRemoveDir
set "RM_TARGET=%~1"
set "RM_TRIES=0"
:RmRetry
set /a RM_TRIES+=1
attrib -r -h -s "%RM_TARGET%\*.*" /s /d >nul 2>&1
rmdir /s /q "%RM_TARGET%" 2>nul
if exist "%RM_TARGET%" if !RM_TRIES! LSS 5 (
    timeout /t 3 /nobreak >nul
    goto RmRetry
)
goto :eof

:: -----------------------------------------------------------------
:: :Cleanup - finds old leftover PitchCorrectVST project folders and
:: related .zip files under Downloads, shows what it found, and only
:: deletes after you type Y. Nothing else in Downloads is touched.
:: This is the merged-in logic from cleanup_pitchcorrect.bat.
:: -----------------------------------------------------------------
:Cleanup
set "CLEAN_ROOT=%USERPROFILE%\Downloads"
if not exist "%CLEAN_ROOT%" goto :eof

echo =====================================================================
echo   Optional cleanup - checking for old leftovers under: %CLEAN_ROOT%
echo =====================================================================
echo.

set "FOUND_ANY=0"
echo [*] Old project folders found:
for /f "delims=" %%d in ('dir /b /s /a:d "%CLEAN_ROOT%\PitchCorrectVST" 2^>nul') do (
    if /i not "%%d"=="%PROJECT_DIR%" (
        echo     - %%d
        set "FOUND_ANY=1"
    )
)
if "%FOUND_ANY%"=="0" echo     ^(none found^)
echo.

echo [*] Related .zip files found:
set "FOUND_ZIP=0"
for /f "delims=" %%z in ('dir /b /s /a:-d "%CLEAN_ROOT%\PitchCorrectVST*.zip" 2^>nul') do (
    echo     - %%z
    set "FOUND_ZIP=1"
)
for /f "delims=" %%z in ('dir /b /s /a:-d "%CLEAN_ROOT%\ahmed*.zip" 2^>nul') do (
    echo     - %%z
    set "FOUND_ZIP=1"
)
if "%FOUND_ZIP%"=="0" echo     ^(none found^)
echo.

if "%FOUND_ANY%"=="0" if "%FOUND_ZIP%"=="0" (
    echo [*] Nothing to clean up. Continuing...
    echo.
    goto :eof
)

echo =====================================================================
echo This would PERMANENTLY DELETE all folders/files listed above.
echo Nothing else under Downloads will be touched, and this project's
echo own folder ^(%PROJECT_DIR%^) is never deleted.
echo =====================================================================
set /p "CLEAN_CONFIRM=Type Y and press Enter to delete them now, anything else to skip: "
if /i not "%CLEAN_CONFIRM%"=="Y" (
    echo [*] Skipped cleanup. Continuing with build...
    echo.
    goto :eof
)
echo.

for /f "delims=" %%d in ('dir /b /s /a:d "%CLEAN_ROOT%\PitchCorrectVST" 2^>nul') do (
    if /i not "%%d"=="%PROJECT_DIR%" if exist "%%d" (
        echo [*] Deleting folder: %%d
        call :ForceRemoveDir "%%d"
        if exist "%%d" (
            echo     [!] Could not fully delete ^(file may be open/locked^): %%d
        ) else (
            echo     [+] Deleted.
        )
    )
)

for /f "delims=" %%z in ('dir /b /s /a:-d "%CLEAN_ROOT%\PitchCorrectVST*.zip" 2^>nul') do (
    echo [*] Deleting file: %%z
    del /f /q "%%z" 2>nul
)
for /f "delims=" %%z in ('dir /b /s /a:-d "%CLEAN_ROOT%\ahmed*.zip" 2^>nul') do (
    echo [*] Deleting file: %%z
    del /f /q "%%z" 2>nul
)

echo.
echo [+] Cleanup finished. Continuing with build...
echo.
goto :eof

:AfterJUCE

:: ---------------------------------------------------------------------
:: 6. Configure and build the VST3 (64-bit -- FL Studio on modern
::    Windows is 64-bit, and the plugin must match).
::    Only the VST3 target is built (not Standalone) to keep this fast;
::    JUCE's CMake support generates a "<Target>_VST3" build target.
::    If a stale build\ cache from a previous run is causing the
::    configure step to fail (e.g. a different generator/arch was used
::    last time), wipe it and retry automatically.
:: ---------------------------------------------------------------------
echo [*] Generating build project files via CMake ^(x64^)...
set "CFG_TRIES=0"
:CMakeConfigRetry
set /a CFG_TRIES+=1
cmake -B build -A x64 -DCMAKE_BUILD_TYPE=Release
if !errorLevel! neq 0 (
    if !CFG_TRIES! LSS 3 (
        echo [!] CMake configuration failed ^(attempt !CFG_TRIES!/3^), wiping cache and retrying...
        call :ForceRemoveDir "build"
        timeout /t 3 /nobreak >nul
        goto CMakeConfigRetry
    )
    echo [X] ERROR: CMake configuration failed after 3 attempts.
    echo     Scroll up for the exact error. Common fixes: free up disk space,
    echo     make sure no other build is running, or re-run this script as
    echo     Administrator.
    pause
    exit /b !errorLevel!
)

echo [*] Compiling VST3 plugin... please wait, this can take a few minutes.
set "BUILD_TRIES=0"
:CMakeBuildRetry
set /a BUILD_TRIES+=1
cmake --build build --config Release --target PitchCorrectVST_VST3 --parallel
if !errorLevel! neq 0 (
    if !BUILD_TRIES! LSS 2 (
        echo [!] Compilation failed ^(attempt !BUILD_TRIES!/2^), retrying once more
        echo     ^(this recovers from transient locks e.g. antivirus scanning
        echo     a freshly-written .obj/.dll file^)...
        timeout /t 5 /nobreak >nul
        goto CMakeBuildRetry
    )
    echo [X] ERROR: Compilation failed after 2 attempts. Scroll up for the
    echo     compiler error above -- that is the real cause and must be
    echo     fixed in the source before this can succeed.
    pause
    exit /b !errorLevel!
)
echo [+] Compilation successful!
echo.

:: ---------------------------------------------------------------------
:: 7. Install the built VST3 into FL Studio's default VST3 folder.
::    JUCE's COPY_PLUGIN_AFTER_BUILD already does this automatically as
::    part of the build step above; the block below is a safety net in
::    case that copy step was blocked (e.g. missing admin rights on a
::    previous run) and also gives explicit success/failure feedback.
:: ---------------------------------------------------------------------
echo [*] Verifying installed VST3 plugin...
if not exist "%VST3_TARGET_DIR%" mkdir "%VST3_TARGET_DIR%"

set "ARTIFACT_PATH=build\PitchCorrectVST_artefacts\Release\VST3"

if not exist "%ARTIFACT_PATH%\PitchCorrect.vst3" (
    echo [!] Expected artifact not found at the usual path, searching build\ ...
    for /f "delims=" %%f in ('dir /b /s /a:d "build\PitchCorrect.vst3" 2^>nul') do set "ARTIFACT_PATH=%%~dpf"
)

if exist "%ARTIFACT_PATH%\PitchCorrect.vst3" (
    set "COPY_TRIES=0"
    :CopyVstRetry
    set /a COPY_TRIES+=1
    xcopy "%ARTIFACT_PATH%\PitchCorrect.vst3" "%VST3_TARGET_DIR%\PitchCorrect.vst3\" /E /I /Y /Q >nul
    if not exist "%VST3_TARGET_DIR%\PitchCorrect.vst3" if !COPY_TRIES! LSS 5 (
        echo [!] Copy to VST3 folder failed ^(attempt !COPY_TRIES!/5, likely
        echo     locked because FL Studio is open^), retrying in 5s...
        echo     Close FL Studio now if it's running.
        timeout /t 5 /nobreak >nul
        goto CopyVstRetry
    )
)

if exist "%VST3_TARGET_DIR%\PitchCorrect.vst3" (
    echo.
    echo =====================================================================
    echo [SUCCESS] PitchCorrect VST3 is installed and ready!
    echo [*] VST3 Path: %VST3_TARGET_DIR%\PitchCorrect.vst3
    echo.
    echo Next steps in FL Studio:
    echo   1. Open FL Studio.
    echo   2. Options -^> Manage Plugins.
    echo   3. Click "Find plugins" ^(or "Find installed plugins"^) to rescan.
    echo   4. PitchCorrect will appear under Effects -^> Manufacturer name.
    echo      ^(If FL Studio was already open, restart it so it picks up
    echo      the new plugin.^)
    echo =====================================================================
) else (
    echo.
    echo [X] ERROR: Could not find or install the compiled .vst3 bundle.
    echo     Expected it under: build\PitchCorrectVST_artefacts\Release\VST3\
    echo     Check the compiler output above for errors.
)

echo.
pause
