#include "CustomLookAndFeel.h"

// Dark grey/blue palette, cyan accent — evokes the Auto-Tune Artist GUI
// without reproducing any of its actual artwork.
const juce::Colour CustomLookAndFeel::backgroundColour { 0xff1a1d23 };
const juce::Colour CustomLookAndFeel::panelColour       { 0xff23272f };
const juce::Colour CustomLookAndFeel::trackColour       { 0xff3a3f4b };
const juce::Colour CustomLookAndFeel::accentColour      { 0xff36c7d6 };
const juce::Colour CustomLookAndFeel::outlineColour     { 0xff40454f };
const juce::Colour CustomLookAndFeel::textColour        { 0xffe6e9ef };
const juce::Colour CustomLookAndFeel::knobTop           { 0xff30343d };
const juce::Colour CustomLookAndFeel::knobBottom        { 0xff1e2127 };
