#include "PitchDetector.h"

// PitchDetector is implemented header-only (all methods are small/inline
// and called per-sample on the audio thread, so keeping them visible to
// the compiler for inlining matters more than translation-unit hygiene).
// This .cpp exists so the class has a single stable place to grow into
// if the YIN implementation is later swapped for MPM or split further.
