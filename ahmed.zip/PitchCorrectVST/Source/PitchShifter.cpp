#include "PitchShifter.h"

// PitchShifter is header-only: it runs entirely on the audio thread and
// benefits from full inlining of its per-frame hot path (STFT analysis,
// cepstral envelope extraction, phase-vocoder pitch shift, ISTFT
// synthesis). This .cpp is kept as the natural landing spot if the
// engine is later split into multiple translation units (e.g. moving
// the cepstral envelope extraction into a standalone, testable class).
