#include "ScaleQuantizer.h"

// ScaleQuantizer is header-only: every method is a small, allocation-free
// pure function well suited to inlining. This .cpp is kept as the natural
// place to add non-inline helpers (e.g. custom/user scale editing) later.
