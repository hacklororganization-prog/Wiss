#pragma once
#include <juce_gui_basics/juce_gui_basics.h>

/**
    CustomLookAndFeel
    ------------------
    Dark grey/blue vector-drawn theme in the spirit of Auto-Tune Artist:
    flat dark panels, a cyan accent for active/pointer elements, and
    hand-drawn (no bitmap assets) rotary knobs so the plugin has zero
    image dependencies.
*/
class CustomLookAndFeel : public juce::LookAndFeel_V4
{
public:
    CustomLookAndFeel()
    {
        setColour (juce::ResizableWindow::backgroundColourId, backgroundColour);
        setColour (juce::Slider::textBoxTextColourId, textColour);
        setColour (juce::Slider::textBoxBackgroundColourId, panelColour);
        setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
        setColour (juce::ComboBox::backgroundColourId, panelColour);
        setColour (juce::ComboBox::textColourId, textColour);
        setColour (juce::ComboBox::outlineColourId, outlineColour);
        setColour (juce::PopupMenu::backgroundColourId, panelColour);
        setColour (juce::PopupMenu::textColourId, textColour);
        setColour (juce::PopupMenu::highlightedBackgroundColourId, accentColour.withAlpha (0.3f));
        setColour (juce::Label::textColourId, textColour);
    }

    void drawRotarySlider (juce::Graphics& g, int x, int y, int width, int height,
                            float sliderPosProportional, float rotaryStartAngle, float rotaryEndAngle,
                            juce::Slider&) override
    {
        auto bounds = juce::Rectangle<float> ((float) x, (float) y, (float) width, (float) height).reduced (6.0f);
        const auto centre = bounds.getCentre();
        const float radius = juce::jmin (bounds.getWidth(), bounds.getHeight()) * 0.5f;
        const float angle = rotaryStartAngle + sliderPosProportional * (rotaryEndAngle - rotaryStartAngle);

        // outer track
        g.setColour (trackColour);
        juce::Path track;
        track.addCentredArc (centre.x, centre.y, radius, radius, 0.0f, rotaryStartAngle, rotaryEndAngle, true);
        g.strokePath (track, juce::PathStrokeType (4.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // active value arc
        g.setColour (accentColour);
        juce::Path valueArc;
        valueArc.addCentredArc (centre.x, centre.y, radius, radius, 0.0f, rotaryStartAngle, angle, true);
        g.strokePath (valueArc, juce::PathStrokeType (4.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // knob body
        const float bodyRadius = radius * 0.62f;
        juce::ColourGradient grad (knobTop, centre.x, centre.y - bodyRadius,
                                    knobBottom, centre.x, centre.y + bodyRadius, false);
        g.setGradientFill (grad);
        g.fillEllipse (centre.x - bodyRadius, centre.y - bodyRadius, bodyRadius * 2.0f, bodyRadius * 2.0f);
        g.setColour (outlineColour);
        g.drawEllipse (centre.x - bodyRadius, centre.y - bodyRadius, bodyRadius * 2.0f, bodyRadius * 2.0f, 1.2f);

        // pointer
        juce::Path pointer;
        const float pointerLength = bodyRadius * 0.82f;
        const float pointerThickness = 3.0f;
        pointer.addRoundedRectangle (-pointerThickness * 0.5f, -pointerLength, pointerThickness, pointerLength * 0.9f, 1.5f);
        pointer.applyTransform (juce::AffineTransform::rotation (angle).translated (centre));
        g.setColour (accentColour);
        g.fillPath (pointer);
    }

    void drawComboBox (juce::Graphics& g, int width, int height, bool,
                        int, int, int, int, juce::ComboBox& box) override
    {
        auto bounds = juce::Rectangle<float> (0, 0, (float) width, (float) height).reduced (1.0f);
        g.setColour (panelColour);
        g.fillRoundedRectangle (bounds, 4.0f);
        g.setColour (outlineColour);
        g.drawRoundedRectangle (bounds, 4.0f, 1.0f);

        const float arrowSize = 6.0f;
        const auto arrowArea = bounds.removeFromRight (24.0f);
        juce::Path arrow;
        arrow.addTriangle (arrowArea.getCentreX() - arrowSize * 0.5f, arrowArea.getCentreY() - arrowSize * 0.25f,
                            arrowArea.getCentreX() + arrowSize * 0.5f, arrowArea.getCentreY() - arrowSize * 0.25f,
                            arrowArea.getCentreX(), arrowArea.getCentreY() + arrowSize * 0.5f);
        g.setColour (box.isEnabled() ? accentColour : outlineColour);
        g.fillPath (arrow);
    }

    juce::Font getComboBoxFont (juce::ComboBox&) override { return juce::Font (juce::FontOptions (14.0f)); }
    juce::Font getLabelFont (juce::Label&) override { return juce::Font (juce::FontOptions (14.0f)); }

    static const juce::Colour backgroundColour;
    static const juce::Colour panelColour;
    static const juce::Colour trackColour;
    static const juce::Colour accentColour;
    static const juce::Colour outlineColour;
    static const juce::Colour textColour;
    static const juce::Colour knobTop;
    static const juce::Colour knobBottom;
};
