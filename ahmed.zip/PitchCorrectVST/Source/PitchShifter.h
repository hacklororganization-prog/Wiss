#pragma once
#include <juce_dsp/juce_dsp.h>
#include <array>
#include <cmath>
#include <memory>
#include <algorithm>

/**
    PitchShifter
    ------------
    Real-time, formant-preserved pitch shifter built on a phase-vocoder
    (STFT -> spectral manipulation -> ISTFT with overlap-add) core.

    WHY PHASE VOCODER INSTEAD OF RAW PSOLA
    ---------------------------------------
    Naive PSOLA / resampling-based pitch shifting moves the *entire*
    spectral envelope (formants) along with the fundamental, which is
    exactly what produces the "chipmunk" (shift up) / "monster" (shift
    down) effect. To pitch-shift *without* dragging the formants along,
    this engine:

      1. Takes an STFT frame and splits its magnitude spectrum into
         SOURCE (the fine harmonic/pitch structure) and FILTER (the
         smooth spectral envelope = vocal tract / formants), using
         real-cepstrum liftering — the standard source-filter separation
         technique.
      2. Pitch-shifts the spectrum using the classic Bernsee-style phase
         vocoder bin-scatter technique (scales bin positions AND their
         true instantaneous frequency by the pitch ratio, tracked via
         phase-difference unwrapping across frames).
      3. Re-extracts the envelope of the *shifted* spectrum (which is now
         wrong -- formants moved with the pitch) and divides it out,
         then multiplies back in the *original* envelope (optionally
         frequency-warped by the Formant Shift parameter). This is
         "spectral envelope substitution": the harmonic content moves,
         the formant shape doesn't (unless you ask it to).

    This is the same family of technique used in commercial-grade
    formant-correct pitch correctors (distinct from simpler consumer
    "hard-tune" plugins that skip formant correction entirely).

    REAL-TIME SAFETY
    -----------------
    - All buffers are fixed-size (std::array) or sized once in prepare().
    - The only heap allocation is the juce::dsp::FFT object itself,
      created in prepare() (never in process()).
    - No locks, no I/O, no exceptions thrown in the hot path.

    LATENCY
    -------
    Algorithmic latency = fftSize samples (you need a full analysis
    window of lookback before the first frame can be transformed).
    At the default fftOrder (10 -> 1024 samples) that's ~23ms @ 44.1kHz.
    Drop fftOrder to 9 (512 samples, ~11.6ms) for lower latency at the
    cost of frequency resolution (weaker formant separation and worse
    low-note tracking); this is a compile-time trade-off you can tune
    below. Report the real value via getLatencySamples() so the host
    can PDC-compensate it (see PluginProcessor::prepareToPlay).
*/
class PitchShifter
{
public:
    //==============================================================
    // Compile-time engine size. 1024 is a good default balance of
    // formant resolution vs. latency for vocals. See note above.
    static constexpr int fftOrder      = 10;
    static constexpr int fftSize       = 1 << fftOrder;      // 1024
    static constexpr int hopSize       = fftSize / 4;        // 256 (75% overlap, COLA-safe with Hann)
    static constexpr int numBins       = fftSize / 2 + 1;    // 513 (DC..Nyquist)
    static constexpr int outputRingSize = fftSize * 2;

    using Complex = juce::dsp::Complex<float>;

    PitchShifter() = default;

    void prepare (double sampleRateIn, int /*maxBlockSize*/)
    {
        sampleRate = sampleRateIn;

        fft = std::make_unique<juce::dsp::FFT> (fftOrder);

        for (int n = 0; n < fftSize; ++n)
            hannWindow[(size_t) n] = 0.5f - 0.5f * std::cos (2.0f * juce::MathConstants<float>::pi
                                                               * (float) n / (float) (fftSize - 1));

        // Liftering cutoff: keep cepstrum quefrencies below this as the
        // "formant envelope" and discard everything above as "pitch fine
        // structure". Tied to sample rate so the ~700Hz separation point
        // (below essentially all fundamentals we'd try to track) stays
        // consistent across sample rates.
        liftCutoff = juce::jlimit (8, fftSize / 4, (int) std::lround (sampleRate / 700.0));

        computeColaNormalisation();

        // Voiced/unvoiced crossfade time constants, converted to a per-hop
        // exponential coefficient. Previously this blend used a hardcoded
        // 0.6f-per-frame constant, which is *frame-rate* dependent rather
        // than time-based: at a different sample rate (or if hopSize is
        // ever changed) the same 0.6f produces a different real-world
        // crossfade duration, which can make zipper artifacts worse or
        // better depending on the session's sample rate. Deriving the
        // coefficient from an explicit millisecond time constant keeps the
        // crossfade duration (and therefore its audible character)
        // consistent across all sample rates.
        // Asymmetric on purpose: engage pitch correction quickly on note
        // onset (short attack) but release back to unvoiced/dry more
        // gradually (longer release) so sustained note tails, breaths, and
        // sibilance ease out instead of cutting the corrected signal away
        // abruptly -- this is what actually removes the audible zipper/
        // click right at voiced->unvoiced transitions.
        voicedAttackCoeff  = computeSmoothingCoefficient (6.0f, sampleRate, hopSize);
        voicedReleaseCoeff = computeSmoothingCoefficient (25.0f, sampleRate, hopSize);

        reset();
        latencySamples = fftSize;
    }

    int getLatencySamples() const noexcept { return latencySamples; }

    /**
        Processes one block, sample by sample.
        @param dryIn                  input (dry, mono) samples
        @param wetOut                 output buffer for pitch/formant-corrected samples
        @param numSamples             number of samples in this block
        @param detectedFreqHz         current estimated input pitch (0 if unvoiced)
        @param targetFreqHz           desired output pitch from the quantizer (0 if unvoiced)
        @param retuneSpeedMs          glide time from detected pitch to target pitch (0 = instant hard-tune)
        @param formantShiftSemitones  -12..+12; independent of pitch shift amount. 0 = natural formants preserved.
        @param voiced                 whether the input frame is currently considered voiced
    */
    void process (const float* dryIn, float* wetOut, int numSamples,
                   float detectedFreqHz, float targetFreqHz,
                   float retuneSpeedMs, float formantShiftSemitones, bool voiced)
    {
        for (int i = 0; i < numSamples; ++i)
        {
            inputHistory[(size_t) (samplesProcessed % fftSize)] = dryIn[i];

            if (--samplesUntilNextFrame == 0)
            {
                processFrame (samplesProcessed + 1, detectedFreqHz, targetFreqHz,
                              retuneSpeedMs, formantShiftSemitones, voiced);
                samplesUntilNextFrame = hopSize;
            }

            const long long readIdx = samplesProcessed - latencySamples + 1;
            if (readIdx >= 0)
            {
                const size_t ringPos = (size_t) (readIdx % outputRingSize);
                wetOut[i] = outputRing[ringPos] / colaNormFactor;
                outputRing[ringPos] = 0.0f; // consumed; slot is free for future frames to reuse
            }
            else
            {
                wetOut[i] = 0.0f; // still filling the initial latency buffer
            }

            ++samplesProcessed;
        }
    }

    void reset()
    {
        inputHistory.fill (0.0f);
        outputRing.fill (0.0f);
        lastInputPhase.fill (0.0f);
        sumPhaseOut.fill (0.0);
        samplesProcessed = 0;
        samplesUntilNextFrame = hopSize;
        smoothedTargetFreq = 0.0f;
        voicedAmount = 0.0f;
    }

private:
    //==============================================================
    // One full STFT analysis -> spectral manipulation -> ISTFT synthesis
    // cycle, run once every hopSize samples.
    void processFrame (long long frameEnd, float detectedFreqHz, float targetFreqHz,
                        float retuneSpeedMs, float formantShiftSemitones, bool voiced)
    {
        // --- windowed analysis frame from the circular input history ---
        for (int n = 0; n < fftSize; ++n)
        {
            const long long absPos = frameEnd - fftSize + n;
            const size_t idx = (size_t) (((absPos % fftSize) + fftSize) % fftSize);
            timeDomain[(size_t) n] = { inputHistory[idx] * hannWindow[(size_t) n], 0.0f };
        }

        fft->perform (timeDomain.data(), freqDomain.data(), false);

        for (int k = 0; k < numBins; ++k)
        {
            magnitude[(size_t) k] = std::abs (freqDomain[(size_t) k]);
            phase[(size_t) k]     = std::arg (freqDomain[(size_t) k]);
        }

        // --- phase-vocoder true-frequency tracking (Bernsee-style) ---
        const double freqPerBin = sampleRate / (double) fftSize;
        const double expct = 2.0 * juce::MathConstants<double>::pi * (double) hopSize / (double) fftSize;
        const double oversamp = (double) fftSize / (double) hopSize;

        for (int k = 0; k < numBins; ++k)
        {
            double tmp = (double) phase[(size_t) k] - (double) lastInputPhase[(size_t) k];
            lastInputPhase[(size_t) k] = phase[(size_t) k];
            tmp -= (double) k * expct;
            tmp = std::remainder (tmp, 2.0 * juce::MathConstants<double>::pi); // wrap to (-pi, pi]
            const double deviationBins = tmp * oversamp / (2.0 * juce::MathConstants<double>::pi);
            trueFreq[(size_t) k] = (float) (((double) k + deviationBins) * freqPerBin);
        }

        // --- glide toward target pitch (retune speed / humanize handled upstream by ScaleQuantizer) ---
        float rawPitchRatio;
        if (voiced && detectedFreqHz > 0.0f && targetFreqHz > 0.0f)
        {
            if (smoothedTargetFreq <= 0.0f)
                smoothedTargetFreq = targetFreqHz; // first voiced frame: snap, no glide-in from silence

            const double glideCoeff = computeGlideCoefficient (retuneSpeedMs);
            smoothedTargetFreq = (float) (glideCoeff * smoothedTargetFreq + (1.0 - glideCoeff) * targetFreqHz);
            rawPitchRatio = smoothedTargetFreq / detectedFreqHz;
        }
        else
        {
            rawPitchRatio = 1.0f; // unvoiced: no pitch manipulation
        }

        // Smoothly blend between "untouched passthrough" and "full effect"
        // across the voiced/unvoiced boundary so consonants/sibilance/breath
        // never get spectrally mangled and there's no zipper click when
        // voicing starts or stops. Sample-rate-correct, asymmetric attack/
        // release exponential smoothing -- see the time-constant comment in
        // prepare().
        const float voicedTarget = voiced ? 1.0f : 0.0f;
        const float coeff = (voicedTarget > voicedAmount) ? voicedAttackCoeff : voicedReleaseCoeff;
        voicedAmount = coeff * voicedAmount + (1.0f - coeff) * voicedTarget;

        const float pitchRatio = juce::jlimit (0.25f, 4.0f, 1.0f + voicedAmount * (rawPitchRatio - 1.0f));
        const float rawFormantRatio = std::pow (2.0f, formantShiftSemitones / 12.0f);
        const float formantRatio = 1.0f + voicedAmount * (rawFormantRatio - 1.0f);

        // --- source/filter split of the ORIGINAL spectrum ---
        extractEnvelope (magnitude, origEnvelope);
        warpEnvelope (origEnvelope, targetEnvelope, formantRatio);

        // --- pitch-shift via spectral bin scatter (Bernsee phase vocoder) ---
        synMagn.fill (0.0f);
        synFreqHz.fill (0.0f);
        for (int k = 0; k < numBins; ++k)
        {
            const int idx = (int) std::lround ((double) k * pitchRatio);
            if (idx >= 0 && idx < numBins)
            {
                synMagn[(size_t) idx] += magnitude[(size_t) k];
                synFreqHz[(size_t) idx] = trueFreq[(size_t) k] * pitchRatio;
            }
        }

        // --- undo the formant shift the scatter just introduced, then
        //     reapply the (optionally user-warped) original envelope ---
        extractEnvelope (synMagn, shiftedEnvelope);
        for (int k = 0; k < numBins; ++k)
        {
            const float correctionGain = juce::jlimit (0.0f, 6.0f,
                targetEnvelope[(size_t) k] / (shiftedEnvelope[(size_t) k] + 1.0e-6f));
            correctedMagn[(size_t) k] = synMagn[(size_t) k] * correctionGain;
        }

        // --- rebuild synthesis phase from the shifted true frequencies ---
        for (int k = 0; k < numBins; ++k)
        {
            double tmp = (double) synFreqHz[(size_t) k];
            tmp -= (double) k * freqPerBin;
            tmp /= freqPerBin;
            tmp = 2.0 * juce::MathConstants<double>::pi * tmp / oversamp;
            tmp += (double) k * expct;
            sumPhaseOut[(size_t) k] += tmp;

            const double ph = sumPhaseOut[(size_t) k];
            freqDomain[(size_t) k] = { correctedMagn[(size_t) k] * (float) std::cos (ph),
                                        correctedMagn[(size_t) k] * (float) std::sin (ph) };
        }
        // Conjugate-symmetric mirror so the inverse transform produces a real signal.
        for (int k = numBins; k < fftSize; ++k)
            freqDomain[(size_t) k] = std::conj (freqDomain[(size_t) (fftSize - k)]);

        fft->perform (freqDomain.data(), timeDomain.data(), true);

        // --- synthesis window + overlap-add into the output ring ---
        for (int n = 0; n < fftSize; ++n)
        {
            const long long absPos = frameEnd - fftSize + n;
            const size_t ringPos = (size_t) (((absPos % outputRingSize) + outputRingSize) % outputRingSize);
            outputRing[ringPos] += timeDomain[(size_t) n].real() * hannWindow[(size_t) n];
        }
    }

    // Cepstral spectral-envelope extraction: separates the smooth
    // "formant" shape from a magnitude spectrum via log-magnitude
    // liftering. Called twice per frame (once on the original spectrum,
    // once on the pitch-shifted one) -- cheap at hop-rate (~172 Hz @
    // 44.1kHz/hop256), all buffers are pre-sized members, no allocation.
    void extractEnvelope (const std::array<float, (size_t) numBins>& mag,
                           std::array<float, (size_t) numBins>& envOut)
    {
        for (int k = 0; k < numBins; ++k)
            logMagFull[(size_t) k] = std::log (mag[(size_t) k] + 1.0e-6f);
        for (int k = numBins; k < fftSize; ++k)
            logMagFull[(size_t) k] = logMagFull[(size_t) (fftSize - k)];

        for (int n = 0; n < fftSize; ++n)
            cepWork[(size_t) n] = { logMagFull[(size_t) n], 0.0f };

        // Inverse transform of a log-magnitude spectrum -> real cepstrum.
        // NB: JUCE's dsp::FFT applies 1/N scaling on the inverse pass so
        // forward->inverse round-trips exactly; if you're on a JUCE
        // version where that isn't true, scale cepWork by 1/fftSize here.
        fft->perform (cepWork.data(), cepResult.data(), true);

        for (int n = 0; n < fftSize; ++n)
        {
            const bool keepLowQuefrency = (n <= liftCutoff) || (n >= fftSize - liftCutoff);
            cepResult[(size_t) n] = keepLowQuefrency ? cepResult[(size_t) n] : Complex (0.0f, 0.0f);
        }

        fft->perform (cepResult.data(), cepWork.data(), false);

        for (int k = 0; k < numBins; ++k)
            envOut[(size_t) k] = std::exp (cepWork[(size_t) k].real());
    }

    // Resamples the envelope along the frequency axis to approximate a
    // formant-frequency shift: ratio > 1 -> brighter / formants up,
    // ratio < 1 -> darker / formants down. ratio == 1 is an identity op.
    void warpEnvelope (const std::array<float, (size_t) numBins>& src,
                        std::array<float, (size_t) numBins>& dst, float ratio) const
    {
        if (std::abs (ratio - 1.0f) < 1.0e-4f)
        {
            dst = src;
            return;
        }

        for (int k = 0; k < numBins; ++k)
        {
            const float srcIndexF = (float) k / ratio;
            const int i0 = (int) std::floor (srcIndexF);
            const int i1 = i0 + 1;
            const float frac = srcIndexF - (float) i0;

            const float s0 = src[(size_t) juce::jlimit (0, numBins - 1, i0)];
            const float s1 = src[(size_t) juce::jlimit (0, numBins - 1, i1)];
            dst[(size_t) k] = s0 * (1.0f - frac) + s1 * frac;
        }
    }

    double computeGlideCoefficient (float retuneSpeedMs) const noexcept
    {
        if (retuneSpeedMs <= 0.01f)
            return 0.0; // instant snap == classic hard-tune sound

        const double timeConstantSamples = (double) retuneSpeedMs * 0.001 * sampleRate;
        return std::exp (-(double) hopSize / std::max (1.0, timeConstantSamples));
    }

    // Converts a millisecond time constant into a per-hop exponential
    // smoothing coefficient, correctly accounting for the actual hop
    // period at the current sample rate (rather than an arbitrary
    // fixed-per-frame blend factor). Called once from prepare(), never
    // from the per-frame hot path.
    static float computeSmoothingCoefficient (float timeConstantMs, double sr, int hop) noexcept
    {
        if (timeConstantMs <= 0.0f)
            return 0.0f; // instant
        const double tauSamples = (double) timeConstantMs * 0.001 * sr;
        return (float) std::exp (-(double) hop / std::max (1.0, tauSamples));
    }

    // Numerically derives the constant-overlap-add normalisation factor
    // for the current window/hop combination rather than hardcoding a
    // formula, so this stays correct if the window function ever changes.
    void computeColaNormalisation()
    {
        std::array<double, (size_t) (fftSize * 3)> acc {};
        for (int shift = -4; shift <= 4; ++shift)
        {
            for (int n = 0; n < fftSize; ++n)
            {
                const int pos = fftSize + shift * hopSize + n;
                if (pos >= 0 && pos < (int) acc.size())
                    acc[(size_t) pos] += (double) hannWindow[(size_t) n] * (double) hannWindow[(size_t) n];
            }
        }
        colaNormFactor = (float) acc[(size_t) (fftSize + fftSize / 2)];
        if (colaNormFactor < 1.0e-6f)
            colaNormFactor = 1.0f; // defensive fallback, should not happen
    }

    //==============================================================
    double sampleRate = 44100.0;
    std::unique_ptr<juce::dsp::FFT> fft;

    std::array<float, (size_t) fftSize> hannWindow {};
    float colaNormFactor = 1.0f;
    int liftCutoff = 32;
    int latencySamples = fftSize;

    std::array<float, (size_t) fftSize> inputHistory {};
    std::array<float, (size_t) outputRingSize> outputRing {};
    long long samplesProcessed = 0;
    int samplesUntilNextFrame = hopSize;

    // Per-frame working buffers (all fixed-size, no per-call allocation)
    std::array<Complex, (size_t) fftSize> timeDomain {};
    std::array<Complex, (size_t) fftSize> freqDomain {};
    std::array<Complex, (size_t) fftSize> cepWork {};
    std::array<Complex, (size_t) fftSize> cepResult {};
    std::array<float, (size_t) fftSize> logMagFull {};

    std::array<float, (size_t) numBins> magnitude {};
    std::array<float, (size_t) numBins> phase {};
    std::array<float, (size_t) numBins> trueFreq {};
    std::array<float, (size_t) numBins> lastInputPhase {};
    std::array<double, (size_t) numBins> sumPhaseOut {};

    std::array<float, (size_t) numBins> origEnvelope {};
    std::array<float, (size_t) numBins> targetEnvelope {};
    std::array<float, (size_t) numBins> shiftedEnvelope {};
    std::array<float, (size_t) numBins> synMagn {};
    std::array<float, (size_t) numBins> synFreqHz {};
    std::array<float, (size_t) numBins> correctedMagn {};

    float smoothedTargetFreq = 0.0f;
    float voicedAmount = 0.0f;
    float voicedAttackCoeff = 0.0f;   // computed once in prepare(), see comment there
    float voicedReleaseCoeff = 0.0f;
};
