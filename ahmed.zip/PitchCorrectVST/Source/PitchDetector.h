#pragma once
#include <vector>
#include <cmath>
#include <cstdint>

/**
    PitchDetector
    -------------
    Real-time fundamental frequency (f0) estimator using the YIN algorithm
    (de Cheveigne & Kawahara, 2002).

    Design notes:
    - Runs on a fixed-size analysis window (default 1024 samples). YIN needs
      roughly two full periods of the lowest frequency you want to track, so
      window size is a direct trade-off against low-note tracking and latency.
      1024 samples @ 44.1kHz ~= 23.2ms, enough to reliably track down to ~85Hz
      (low male vocal range) with margin.
    - Uses a sliding hop (default 256 samples) so a new pitch estimate is
      produced every hop, not only once per full window, which keeps the
      *effective* update rate high even though each estimate looks at a
      longer history. This also matches PitchShifter's STFT hop size, so
      the two analysis clocks stay in step.
    - Voiced/unvoiced decisions are debounced with a small hysteresis
      counter (see isVoicedRaw / voicedRunLength below): a single noisy
      frame flipping the periodicity threshold no longer toggles the
      shifter's voiced/unvoiced processing path on its own, which is what
      previously could produce audible zipper artifacts right at the edge
      of sustained notes, breaths, and sibilance.
    - Not thread-safe by itself; intended to be driven from the audio thread
      only, with parameters read via std::atomic elsewhere.
*/
class PitchDetector
{
public:
    PitchDetector() = default;

    void prepare (double sampleRateIn, int windowSizeIn = 1024, int hopSizeIn = 256)
    {
        sampleRate = sampleRateIn;
        windowSize = windowSizeIn;
        hopSize = hopSizeIn;

        inputRingBuffer.assign ((size_t) windowSize, 0.0f);
        linearBuffer.assign ((size_t) windowSize, 0.0f);   // pre-sized once here; analyse() only ever
                                                             // overwrites existing elements, never resizes
        yinBuffer.assign ((size_t) (windowSize / 2), 0.0);
        writePos = 0;
        samplesSinceLastAnalysis = 0;

        currentFrequencyHz = 0.0f;
        currentConfidence = 0.0f;
        isVoiced = false;
        isVoicedRaw = false;
        voicedRunLength = 0;
        unvoicedRunLength = 0;
    }

    /** Push one sample of mono audio in. Call once per sample from the audio
        thread. Internally this fills a ring buffer and triggers a new YIN
        analysis every `hopSize` samples. */
    void pushSample (float sample) noexcept
    {
        inputRingBuffer[(size_t) writePos] = sample;
        writePos = (writePos + 1) % windowSize;

        if (++samplesSinceLastAnalysis >= hopSize)
        {
            samplesSinceLastAnalysis = 0;
            analyse();
        }
    }

    /** Latest estimated fundamental frequency in Hz. 0.0f if unvoiced /
        no pitch could be determined. */
    float getFrequencyHz() const noexcept   { return currentFrequencyHz; }

    /** Confidence of the latest estimate in [0, 1], derived from the YIN
        CMND minimum value (lower = more periodic = higher confidence). */
    float getConfidence() const noexcept    { return currentConfidence; }

    /** Debounced voiced/unvoiced flag -- prefer this over inspecting
        confidence yourself; see class notes on hysteresis. */
    bool getIsVoiced() const noexcept       { return isVoiced; }

    /** Analysis latency introduced by the window, in samples. Useful for
        the processor to report PDC (plugin delay compensation) if the
        shifter is run in a look-ahead configuration. */
    int getAnalysisLatencySamples() const noexcept { return windowSize; }

    void setYinThreshold (float t) noexcept { yinThreshold = t; }

private:
    void analyse()
    {
        // Copy ring buffer into a linear working buffer starting at the
        // oldest sample so indices are contiguous for the difference function.
        // NOTE: linearBuffer is pre-sized once in prepare() (RT-safety fix) --
        // do NOT call resize()/reserve() here, this runs on the audio thread
        // every `hopSize` samples and must never allocate.
        for (int i = 0; i < windowSize; ++i)
            linearBuffer[(size_t) i] = inputRingBuffer[(size_t) ((writePos + i) % windowSize)];

        const int halfWindow = windowSize / 2;

        // --- Step 1: difference function d(tau) ---
        yinBuffer[0] = 0.0;
        for (int tau = 1; tau < halfWindow; ++tau)
        {
            double sum = 0.0;
            for (int i = 0; i < halfWindow; ++i)
            {
                const double delta = (double) linearBuffer[(size_t) i]
                                    - (double) linearBuffer[(size_t) (i + tau)];
                sum += delta * delta;
            }
            yinBuffer[(size_t) tau] = sum;
        }

        // --- Step 2: cumulative mean normalized difference (CMND) ---
        double runningSum = 0.0;
        yinBuffer[0] = 1.0;
        for (int tau = 1; tau < halfWindow; ++tau)
        {
            runningSum += yinBuffer[(size_t) tau];
            yinBuffer[(size_t) tau] = runningSum == 0.0
                ? 1.0
                : yinBuffer[(size_t) tau] * tau / runningSum;
        }

        // --- Step 3: absolute threshold ---
        int tauEstimate = -1;
        for (int tau = 2; tau < halfWindow; ++tau)
        {
            if (yinBuffer[(size_t) tau] < yinThreshold)
            {
                // walk forward while the CMND keeps decreasing to find the
                // local minimum rather than just the first dip below threshold
                while (tau + 1 < halfWindow && yinBuffer[(size_t) (tau + 1)] < yinBuffer[(size_t) tau])
                    ++tau;
                tauEstimate = tau;
                break;
            }
        }

        if (tauEstimate == -1)
        {
            updateVoicedHysteresis (false);
            currentConfidence = 0.0f;
            return;
        }

        // --- Step 4: parabolic interpolation around tauEstimate for sub-sample accuracy ---
        const double betterTau = parabolicInterpolation (tauEstimate);

        if (betterTau <= 0.0)
        {
            updateVoicedHysteresis (false);
            return;
        }

        const float freq = (float) (sampleRate / betterTau);

        // Reject implausible vocal-range results (roughly 60Hz - 1200Hz)
        if (freq < 60.0f || freq > 1200.0f)
        {
            updateVoicedHysteresis (false);
            return;
        }

        currentFrequencyHz = freq;
        currentConfidence = juce_jlimit (0.0, 1.0, 1.0 - yinBuffer[(size_t) tauEstimate]);
        updateVoicedHysteresis (true);
    }

    // Requires a short run of consistent frames before flipping the
    // public voiced flag, in either direction. Keeps single noisy hops
    // (a breath consonant that briefly looks periodic, or a genuinely
    // voiced frame that momentarily dips below threshold) from toggling
    // the pitch shifter's processing path and causing a click/artifact.
    void updateVoicedHysteresis (bool rawVoiced) noexcept
    {
        isVoicedRaw = rawVoiced;

        if (rawVoiced)
        {
            unvoicedRunLength = 0;
            if (++voicedRunLength >= voicedOnFrames)
                isVoiced = true;
        }
        else
        {
            voicedRunLength = 0;
            if (++unvoicedRunLength >= voicedOffFrames)
                isVoiced = false;
        }
    }

    double parabolicInterpolation (int tauEstimate) const
    {
        const int halfWindow = windowSize / 2;
        int x0 = (tauEstimate < 1) ? tauEstimate : tauEstimate - 1;
        int x2 = (tauEstimate + 1 < halfWindow) ? tauEstimate + 1 : tauEstimate;

        if (x0 == tauEstimate) return (yinBuffer[(size_t) tauEstimate] <= yinBuffer[(size_t) x2]) ? tauEstimate : x2;
        if (x2 == tauEstimate) return (yinBuffer[(size_t) tauEstimate] <= yinBuffer[(size_t) x0]) ? tauEstimate : x0;

        const double s0 = yinBuffer[(size_t) x0];
        const double s1 = yinBuffer[(size_t) tauEstimate];
        const double s2 = yinBuffer[(size_t) x2];

        const double denom = (s2 + s0 - 2.0 * s1);
        if (std::abs (denom) < 1e-12)
            return tauEstimate;

        return tauEstimate + 0.5 * (s0 - s2) / denom;
    }

    static double juce_jlimit (double lo, double hi, double v) { return v < lo ? lo : (v > hi ? hi : v); }

    double sampleRate = 44100.0;
    int windowSize = 1024;
    int hopSize = 256;
    float yinThreshold = 0.15f; // lower = stricter periodicity requirement

    std::vector<float> inputRingBuffer;
    std::vector<float> linearBuffer;
    std::vector<double> yinBuffer;
    int writePos = 0;
    int samplesSinceLastAnalysis = 0;

    float currentFrequencyHz = 0.0f;
    float currentConfidence = 0.0f;

    bool isVoiced = false;
    bool isVoicedRaw = false;
    int voicedRunLength = 0;
    int unvoicedRunLength = 0;
    static constexpr int voicedOnFrames = 2;   // ~2 hops (~11.6ms @ hop256/44.1k) to confirm voiced
    static constexpr int voicedOffFrames = 3;  // slightly slower to drop out, avoids chopping note tails
};
