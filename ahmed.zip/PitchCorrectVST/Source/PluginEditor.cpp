#include "PluginProcessor.h"
#include "PluginEditor.h"

PitchCorrectAudioProcessorEditor::PitchCorrectAudioProcessorEditor (PitchCorrectAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p), pitchMeter (p)
{
    setLookAndFeel (&lookAndFeel);

    titleLabel.setText ("PITCHCORRECT", juce::dontSendNotification);
    titleLabel.setFont (juce::Font (juce::FontOptions (20.0f, juce::Font::bold)));
    titleLabel.setColour (juce::Label::textColourId, CustomLookAndFeel::accentColour);
    titleLabel.setJustificationType (juce::Justification::centredLeft);
    addAndMakeVisible (titleLabel);

    // --- Key / Scale dropdowns ---
    for (int i = 0; i < (int) ScaleQuantizer::Key::Count; ++i)
        keyBox.addItem (ScaleQuantizer::getKeyName ((ScaleQuantizer::Key) i), i + 1);
    for (int i = 0; i < (int) ScaleQuantizer::Scale::Count; ++i)
        scaleBox.addItem (ScaleQuantizer::getScaleName ((ScaleQuantizer::Scale) i), i + 1);

    addAndMakeVisible (keyBox);
    addAndMakeVisible (scaleBox);

    keyLabel.setText ("KEY", juce::dontSendNotification);
    scaleLabel.setText ("SCALE", juce::dontSendNotification);
    for (auto* l : { &keyLabel, &scaleLabel })
    {
        l->setJustificationType (juce::Justification::centredLeft);
        l->setColour (juce::Label::textColourId, CustomLookAndFeel::textColour.withAlpha (0.7f));
        l->setFont (juce::Font (juce::FontOptions (12.0f)));
        addAndMakeVisible (l);
    }

    keyAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (
        audioProcessor.apvts, ParamIDs::key, keyBox);
    scaleAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (
        audioProcessor.apvts, ParamIDs::scale, scaleBox);

    // --- Knobs ---
    configureKnob (retuneSpeedKnob, retuneSpeedLabel, "RETUNE SPEED");
    configureKnob (humanizeKnob, humanizeLabel, "HUMANIZE");
    configureKnob (mixKnob, mixLabel, "MIX");

    retuneAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        audioProcessor.apvts, ParamIDs::retuneSpeed, retuneSpeedKnob);
    humanizeAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        audioProcessor.apvts, ParamIDs::humanize, humanizeKnob);
    mixAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        audioProcessor.apvts, ParamIDs::mix, mixKnob);

    addAndMakeVisible (pitchMeter);

    setResizable (true, true);
    setResizeLimits (520, 360, 900, 620);
    setSize (620, 420);
}

PitchCorrectAudioProcessorEditor::~PitchCorrectAudioProcessorEditor()
{
    setLookAndFeel (nullptr);
}

void PitchCorrectAudioProcessorEditor::configureKnob (juce::Slider& slider, juce::Label& label, const juce::String& labelText)
{
    slider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    slider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 80, 18);
    slider.setRotaryParameters (juce::MathConstants<float>::pi * 1.2f,
                                 juce::MathConstants<float>::pi * 2.8f, true);
    addAndMakeVisible (slider);

    label.setText (labelText, juce::dontSendNotification);
    label.setJustificationType (juce::Justification::centred);
    label.setColour (juce::Label::textColourId, CustomLookAndFeel::textColour.withAlpha (0.8f));
    label.setFont (juce::Font (juce::FontOptions (12.0f, juce::Font::bold)));
    addAndMakeVisible (label);
}

void PitchCorrectAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (CustomLookAndFeel::backgroundColour);

    // subtle top accent bar
    g.setColour (CustomLookAndFeel::accentColour.withAlpha (0.15f));
    g.fillRect (getLocalBounds().removeFromTop (4));
}

void PitchCorrectAudioProcessorEditor::resized()
{
    auto area = getLocalBounds().reduced (16);

    auto header = area.removeFromTop (32);
    titleLabel.setBounds (header);

    area.removeFromTop (8);

    // Key / scale row
    auto dropdownRow = area.removeFromTop (56);
    auto keyArea = dropdownRow.removeFromLeft (dropdownRow.getWidth() / 2).reduced (4, 0);
    auto scaleArea = dropdownRow.reduced (4, 0);

    keyLabel.setBounds (keyArea.removeFromTop (16));
    keyBox.setBounds (keyArea.reduced (0, 2));

    scaleLabel.setBounds (scaleArea.removeFromTop (16));
    scaleBox.setBounds (scaleArea.reduced (0, 2));

    area.removeFromTop (12);

    // Pitch meter
    pitchMeter.setBounds (area.removeFromTop (70));

    area.removeFromTop (16);

    // Knob row
    auto knobRow = area.removeFromTop (area.getHeight());
    const int knobWidth = knobRow.getWidth() / 3;

    auto layoutKnob = [] (juce::Rectangle<int> cell, juce::Slider& slider, juce::Label& label)
    {
        auto labelArea = cell.removeFromTop (18);
        label.setBounds (labelArea);
        slider.setBounds (cell.reduced (10));
    };

    layoutKnob (knobRow.removeFromLeft (knobWidth), retuneSpeedKnob, retuneSpeedLabel);
    layoutKnob (knobRow.removeFromLeft (knobWidth), humanizeKnob, humanizeLabel);
    layoutKnob (knobRow, mixKnob, mixLabel);
}
