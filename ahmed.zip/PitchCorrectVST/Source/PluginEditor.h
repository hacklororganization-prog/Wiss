#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "PluginProcessor.h"
#include "CustomLookAndFeel.h"
#include "ScaleQuantizer.h"

/** Small real-time widget: shows detected pitch vs. quantized target on a
    horizontal note strip, plus a numeric readout. Polls the processor's
    MeterState via a timer (safe: only atomics are read, no locking). */
class PitchMeterComponent : public juce::Component, private juce::Timer
{
public:
    explicit PitchMeterComponent (PitchCorrectAudioProcessor& p) : processor (p)
    {
        startTimerHz (30);
    }

    void paint (juce::Graphics& g) override
    {
        auto bounds = getLocalBounds().toFloat();
        g.setColour (CustomLookAndFeel::panelColour);
        g.fillRoundedRectangle (bounds, 6.0f);
        g.setColour (CustomLookAndFeel::outlineColour);
        g.drawRoundedRectangle (bounds.reduced (0.5f), 6.0f, 1.0f);

        auto inner = bounds.reduced (10.0f);

        if (! voiced || detectedHz <= 0.0f)
        {
            g.setColour (CustomLookAndFeel::textColour.withAlpha (0.4f));
            g.setFont (juce::Font (juce::FontOptions (14.0f)));
            g.drawText ("-- no pitch detected --", inner, juce::Justification::centred);
            return;
        }

        const double detectedMidi = ScaleQuantizer::freqToMidi (detectedHz);
        const double targetMidi   = targetHz > 0.0f ? ScaleQuantizer::freqToMidi (targetHz) : detectedMidi;

        // Map a +/- 1 semitone window around the target note across the width.
        const double windowSemitones = 1.0;
        const double loMidi = targetMidi - windowSemitones;
        const double hiMidi = targetMidi + windowSemitones;

        auto midiToX = [&] (double midi)
        {
            const double t = juce::jlimit (0.0, 1.0, (midi - loMidi) / (hiMidi - loMidi));
            return inner.getX() + (float) t * inner.getWidth();
        };

        // centre line = in-tune target
        const float centreX = midiToX (targetMidi);
        g.setColour (CustomLookAndFeel::accentColour.withAlpha (0.5f));
        g.drawLine (centreX, inner.getY(), centreX, inner.getBottom(), 2.0f);

        // detected pitch marker
        const float detectedX = midiToX (detectedMidi);
        const float markerRadius = 7.0f;
        const bool inTune = std::abs (detectedMidi - targetMidi) < 0.08;
        g.setColour (inTune ? juce::Colour (0xff4fe37a) : CustomLookAndFeel::accentColour);
        g.fillEllipse (detectedX - markerRadius, inner.getCentreY() - markerRadius, markerRadius * 2.0f, markerRadius * 2.0f);

        // note name label
        const int nearestNote = (int) std::round (targetMidi);
        const auto noteName = ScaleQuantizer::getKeyName ((ScaleQuantizer::Key) (((nearestNote % 12) + 12) % 12));
        const int octave = nearestNote / 12 - 1;

        g.setColour (CustomLookAndFeel::textColour);
        g.setFont (juce::Font (juce::FontOptions (22.0f, juce::Font::bold)));
        g.drawText (juce::String (noteName) + juce::String (octave), inner.removeFromLeft (70.0f),
                     juce::Justification::centredLeft);

        g.setFont (juce::Font (juce::FontOptions (12.0f)));
        g.setColour (CustomLookAndFeel::textColour.withAlpha (0.6f));
        g.drawText (juce::String (detectedHz, 1) + " Hz -> " + juce::String (targetHz, 1) + " Hz",
                     getLocalBounds().removeFromBottom (18).reduced (10, 0),
                     juce::Justification::centredRight);
    }

private:
    void timerCallback() override
    {
        detectedHz = processor.meterState.detectedFreqHz.load();
        targetHz   = processor.meterState.targetFreqHz.load();
        voiced     = processor.meterState.voiced.load();
        repaint();
    }

    PitchCorrectAudioProcessor& processor;
    float detectedHz = 0.0f;
    float targetHz = 0.0f;
    bool voiced = false;
};

class PitchCorrectAudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    explicit PitchCorrectAudioProcessorEditor (PitchCorrectAudioProcessor&);
    ~PitchCorrectAudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void configureKnob (juce::Slider& slider, juce::Label& label, const juce::String& labelText);

    PitchCorrectAudioProcessor& audioProcessor;
    CustomLookAndFeel lookAndFeel;

    juce::ComboBox keyBox, scaleBox;
    juce::Label keyLabel, scaleLabel;

    juce::Slider retuneSpeedKnob, humanizeKnob, mixKnob;
    juce::Label retuneSpeedLabel, humanizeLabel, mixLabel;

    PitchMeterComponent pitchMeter;

    juce::Label titleLabel;

    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> keyAttachment, scaleAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> retuneAttachment, humanizeAttachment, mixAttachment;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (PitchCorrectAudioProcessorEditor)
};
