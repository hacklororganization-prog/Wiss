#include "PluginProcessor.h"
#include "PluginEditor.h"

namespace
{
    // Writes RBJ-cookbook high-shelf biquad coefficients directly into the
    // 5-element array already owned by an existing
    // juce::dsp::IIR::Coefficients<float> object, using the identical math
    // that juce::dsp::IIR::Coefficients<float>::makeHighShelf() uses
    // internally to build a *new* Coefficients object.
    //
    // Why this exists: makeHighShelf() itself is not RT-safe -- it
    // heap-allocates a brand-new Coefficients (and its backing Array<float>)
    // on every call via `new Coefficients(...)`. Calling it from
    // processBlock() (as the original code did, once per block) is a
    // real-time audio thread violation. juce::Array<float>::set() on an
    // in-range index, by contrast, only ever writes into already-owned
    // storage -- it cannot trigger a reallocation. So: allocate the
    // Coefficients object itself once, in prepareToPlay() (see
    // PitchCorrectAudioProcessor::prepareToPlay), and from then on only
    // ever mutate its contents in place from here.
    void updateHighShelfInPlace (juce::dsp::IIR::Coefficients<float>& coeffs,
                                  double sampleRate, float frequency,
                                  float q, float gainLinear) noexcept
    {
        const float A            = juce::jmax (0.0f, std::sqrt (gainLinear));
        const float aMinus1      = A - 1.0f;
        const float aPlus1       = A + 1.0f;
        const float omega        = juce::MathConstants<float>::twoPi
                                    * juce::jmax (frequency, 2.0f) / (float) sampleRate;
        const float coso         = std::cos (omega);
        const float beta         = std::sin (omega) * std::sqrt (A) / q;
        const float aMinus1Coso  = aMinus1 * coso;

        const float b0 = A * (aPlus1 + aMinus1Coso + beta);
        const float b1 = A * -2.0f * (aMinus1 + aPlus1 * coso);
        const float b2 = A * (aPlus1 + aMinus1Coso - beta);
        const float a0 = aPlus1 - aMinus1Coso + beta;
        const float a1 = 2.0f * (aMinus1 - aPlus1 * coso);
        const float a2 = aPlus1 - aMinus1Coso - beta;

        jassert (a0 != 0.0f);
        const float a0inv = 1.0f / a0;

        auto& c = coeffs.coefficients;
        jassert (c.size() == 5); // must already be allocated by an earlier makeHighShelf() call
        c.set (0, b0 * a0inv);
        c.set (1, b1 * a0inv);
        c.set (2, b2 * a0inv);
        c.set (3, a1 * a0inv);
        c.set (4, a2 * a0inv);
    }
}

PitchCorrectAudioProcessor::PitchCorrectAudioProcessor()
    : AudioProcessor (BusesProperties()
                        .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                        .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "PARAMETERS", createParameterLayout())
{
}

PitchCorrectAudioProcessor::~PitchCorrectAudioProcessor() = default;

juce::AudioProcessorValueTreeState::ParameterLayout PitchCorrectAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    juce::StringArray keyChoices;
    for (int i = 0; i < (int) ScaleQuantizer::Key::Count; ++i)
        keyChoices.add (ScaleQuantizer::getKeyName ((ScaleQuantizer::Key) i));

    params.push_back (std::make_unique<juce::AudioParameterChoice> (
        juce::ParameterID { ParamIDs::key, 1 }, "Key", keyChoices, 0));

    juce::StringArray scaleChoices;
    for (int i = 0; i < (int) ScaleQuantizer::Scale::Count; ++i)
        scaleChoices.add (ScaleQuantizer::getScaleName ((ScaleQuantizer::Scale) i));

    params.push_back (std::make_unique<juce::AudioParameterChoice> (
        juce::ParameterID { ParamIDs::scale, 1 }, "Scale", scaleChoices, 0));

    // 0ms = instantaneous hard-tune (classic T-Pain / trap snap-to-pitch).
    // Larger values glide exponentially -- see PitchShifter::computeGlideCoefficient.
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { ParamIDs::retuneSpeed, 1 }, "Retune Speed",
        juce::NormalisableRange<float> (0.0f, 100.0f, 0.1f), 0.0f,
        juce::AudioParameterFloatAttributes().withLabel ("ms")));

    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { ParamIDs::humanize, 1 }, "Humanize",
        juce::NormalisableRange<float> (0.0f, 100.0f, 0.1f), 0.0f,
        juce::AudioParameterFloatAttributes().withLabel ("%")));

    // Independent of pitch shift amount: 0 = natural formants preserved
    // regardless of how far the pitch is corrected. Negative = warmer/
    // deeper/more emotional vibe, positive = brighter/more forward/
    // aggressive presence (see PitchShifter's envelope-warp step).
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { ParamIDs::formantShift, 1 }, "Formant Shift",
        juce::NormalisableRange<float> (-12.0f, 12.0f, 0.01f), 0.0f,
        juce::AudioParameterFloatAttributes().withLabel ("st")));

    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { ParamIDs::air, 1 }, "Air",
        juce::NormalisableRange<float> (0.0f, 100.0f, 0.1f), 30.0f,
        juce::AudioParameterFloatAttributes().withLabel ("%")));

    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { ParamIDs::mix, 1 }, "Mix",
        juce::NormalisableRange<float> (0.0f, 100.0f, 0.1f), 100.0f,
        juce::AudioParameterFloatAttributes().withLabel ("%")));

    return { params.begin(), params.end() };
}

void PitchCorrectAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    currentSampleRate = sampleRate;

    pitchDetector.prepare (sampleRate, 1024, 256);
    pitchShifter.prepare (sampleRate, samplesPerBlock);

    wetBuffer.setSize (2, samplesPerBlock);
    monoAnalysisBuffer.setSize (1, samplesPerBlock);

    // Allocate the shared coefficients object exactly once, here in
    // prepareToPlay() -- this is the ONLY heap allocation for the air
    // filter's coefficients for the lifetime of this prepare()/
    // releaseResources() cycle. Both channel filters point at the same
    // Ptr (assignment, not copy) so that every subsequent update -- done
    // in place via updateHighShelfInPlace() -- is instantly visible to
    // both channels without re-assigning anything.
    airCoefficients = juce::dsp::IIR::Coefficients<float>::makeHighShelf (
        sampleRate, 11000.0f, 0.7f, 1.0f /* unity gain until the first real update below */);

    juce::dsp::ProcessSpec airSpec { sampleRate, (juce::uint32) samplesPerBlock, 1 };
    for (auto& f : airFilter)
    {
        f.coefficients = airCoefficients;
        f.prepare (airSpec);
        f.reset();
    }

    airAmountSmoothed.reset (sampleRate, 0.02); // 20ms ramp: avoids zippering when automated
    airAmountSmoothed.setCurrentAndTargetValue (apvts.getRawParameterValue (ParamIDs::air)->load() / 100.0f);
    lastAppliedAirAmount01 = -1.0f; // force the first processBlock to compute real coefficients
    updateAirFilterCoefficients (airAmountSmoothed.getCurrentValue());

    // --- Latency / PDC ---
    // Only the phase vocoder (PitchShifter) actually delays the audio
    // signal on its way through the plugin: it buffers `fftSize` samples
    // of lookback before the first output sample can be produced, and
    // every sample after that comes out exactly `fftSize` samples after
    // its corresponding input sample (see PitchShifter::process()).
    //
    // PitchDetector's analysis window does NOT add to that delay -- it
    // runs in parallel off the same input stream purely to *estimate* a
    // target frequency; it doesn't hold audio samples back. The previous
    // implementation summed both windows (pitchDetector.getAnalysisLatencySamples()
    // + pitchShifter.getLatencySamples()), which told the host the plugin
    // needed ~46ms of PDC when the real, audible signal-path delay is only
    // ~23ms (fftSize @ 44.1kHz). Over-reporting latency like this is
    // exactly the kind of bug that produces audible extra delay/drift
    // during live headphone monitoring and direct-to-DAW tracking in FL
    // Studio (and any other host that trusts getLatencySamples() to align
    // dry/wet or punch-in timing) -- so report only the real number.
    setLatencySamples (pitchShifter.getLatencySamples());
}

void PitchCorrectAudioProcessor::releaseResources()
{
}

bool PitchCorrectAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto mono = juce::AudioChannelSet::mono();
    const auto stereo = juce::AudioChannelSet::stereo();

    const auto in = layouts.getMainInputChannelSet();
    const auto out = layouts.getMainOutputChannelSet();

    if (in != out) return false;
    return in == mono || in == stereo;
}

void PitchCorrectAudioProcessor::updateAirFilterCoefficients (float airAmount01)
{
    // Called every processBlock (the "Air" amount is continuously smoothed
    // for automation), so this must be allocation-free -- see the
    // updateHighShelfInPlace() comment at the top of this file for why
    // makeHighShelf() itself can't be used here directly.
    airAmount01 = juce::jlimit (0.0f, 1.0f, airAmount01);

    // Skip the (cheap, but non-zero) trig work entirely once the smoothed
    // value has settled and stopped moving, rather than recomputing
    // identical coefficients every single block.
    if (std::abs (airAmount01 - lastAppliedAirAmount01) < 1.0e-5f)
        return;
    lastAppliedAirAmount01 = airAmount01;

    // Subtle high shelf around 11kHz -- adds "polish"/crispness to the
    // corrected vocal without simply cranking existing sibilance. Max
    // +6dB at 100% keeps this tasteful rather than harsh.
    const float gainDb = juce::jmap (airAmount01, 0.0f, 1.0f, 0.0f, 6.0f);
    const float gainLinear = juce::Decibels::decibelsToGain (gainDb);

    jassert (airCoefficients != nullptr); // must have been allocated in prepareToPlay()
    updateHighShelfInPlace (*airCoefficients, currentSampleRate, 11000.0f, 0.7f, gainLinear);

    // No need to touch airFilter[i].coefficients here at all -- both
    // filters already hold the same Ptr as airCoefficients (assigned once
    // in prepareToPlay), so mutating *airCoefficients above is immediately
    // visible to both channels.
}

void PitchCorrectAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    const int numSamples = buffer.getNumSamples();
    const int numChannels = buffer.getNumChannels();

    if (numSamples == 0)
        return;

    // --- read parameters (audio thread: atomics via APVTS, cheap) ---
    const int keyIndex   = (int) *apvts.getRawParameterValue (ParamIDs::key);
    const int scaleIndex = (int) *apvts.getRawParameterValue (ParamIDs::scale);
    const float retuneMs = apvts.getRawParameterValue (ParamIDs::retuneSpeed)->load();
    const float humanizePct = apvts.getRawParameterValue (ParamIDs::humanize)->load();
    const float formantShiftSt = apvts.getRawParameterValue (ParamIDs::formantShift)->load();
    const float airPct = apvts.getRawParameterValue (ParamIDs::air)->load();
    const float mixPct = apvts.getRawParameterValue (ParamIDs::mix)->load();

    scaleQuantizer.setKey ((ScaleQuantizer::Key) keyIndex);
    scaleQuantizer.setScale ((ScaleQuantizer::Scale) scaleIndex);

    const float humanizeNorm = humanizePct / 100.0f;
    const float mixNorm = mixPct / 100.0f;

    airAmountSmoothed.setTargetValue (airPct / 100.0f);
    updateAirFilterCoefficients (airAmountSmoothed.getNextValue());

    // --- build mono analysis signal (sum of input channels) ---
    monoAnalysisBuffer.setSize (1, numSamples, false, false, true);
    auto* mono = monoAnalysisBuffer.getWritePointer (0);

    if (numChannels == 1)
    {
        monoAnalysisBuffer.copyFrom (0, 0, buffer, 0, 0, numSamples);
    }
    else
    {
        monoAnalysisBuffer.copyFrom (0, 0, buffer, 0, 0, numSamples);
        for (int ch = 1; ch < numChannels; ++ch)
            monoAnalysisBuffer.addFrom (0, 0, buffer, ch, 0, numSamples);
        monoAnalysisBuffer.applyGain (1.0f / (float) numChannels);
    }

    // --- run pitch detection + quantization sample-by-sample ---
    wetBuffer.setSize (juce::jmax (1, numChannels), numSamples, false, false, true);
    auto* wetMono = wetBuffer.getWritePointer (0);

    // Only the block's *final* target frequency ever gets used (both for
    // the meter and for the single pitchShifter.process() call below), so
    // there's no need to buffer one value per sample: a plain stack scalar
    // replaces what was previously a thread_local std::vector<float> that
    // resize()'d on every block -- a heap allocation on the audio thread
    // whenever the host changed its block size.
    float lastTargetFreq = 0.0f;

    for (int i = 0; i < numSamples; ++i)
    {
        pitchDetector.pushSample (mono[i]);
        const float detected = pitchDetector.getFrequencyHz();
        const bool voicedNow = pitchDetector.getIsVoiced();

        lastTargetFreq = 0.0f;
        if (voicedNow && detected > 0.0f)
            lastTargetFreq = (float) scaleQuantizer.quantizeFrequency ((double) detected, humanizeNorm);
    }

    // Update meter state once per block with the last sample's values
    // (sufficient for a UI refreshing at ~30-60Hz).
    meterState.detectedFreqHz.store (pitchDetector.getFrequencyHz());
    meterState.targetFreqHz.store (lastTargetFreq);
    meterState.voiced.store (pitchDetector.getIsVoiced());

    // The shifter internally analyses on its own STFT hop clock (see
    // PitchShifter), so per-sample granularity here matters far less than
    // it would for a time-domain approach; feeding it the block's current
    // detected/target frequency and letting its own frame-rate glide
    // handle the rest is accurate and keeps this call simple.
    pitchShifter.process (mono, wetMono, numSamples,
                           pitchDetector.getFrequencyHz(),
                           lastTargetFreq,
                           retuneMs, formantShiftSt,
                           pitchDetector.getIsVoiced());

    // duplicate wet mono to any additional channels
    for (int ch = 1; ch < wetBuffer.getNumChannels(); ++ch)
        wetBuffer.copyFrom (ch, 0, wetBuffer, 0, 0, numSamples);

    // --- Air EQ: subtle high-shelf polish on the wet signal only ---
    for (int ch = 0; ch < wetBuffer.getNumChannels() && ch < maxAirChannels; ++ch)
    {
        juce::dsp::AudioBlock<float> block (wetBuffer.getArrayOfWritePointers() + ch, 1, (size_t) numSamples);
        juce::dsp::ProcessContextReplacing<float> context (block);
        airFilter[(size_t) ch].process (context);
    }

    // --- dry/wet mix back into the host buffer ---
    for (int ch = 0; ch < numChannels; ++ch)
    {
        auto* dry = buffer.getWritePointer (ch);
        const auto* wet = wetBuffer.getReadPointer (juce::jmin (ch, wetBuffer.getNumChannels() - 1));

        for (int i = 0; i < numSamples; ++i)
            dry[i] = dry[i] * (1.0f - mixNorm) + wet[i] * mixNorm;
    }
}

juce::AudioProcessorEditor* PitchCorrectAudioProcessor::createEditor()
{
    return new PitchCorrectAudioProcessorEditor (*this);
}

void PitchCorrectAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    if (auto state = apvts.copyState(); state.isValid())
    {
        juce::MemoryOutputStream stream (destData, true);
        state.writeToStream (stream);
    }
}

void PitchCorrectAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    auto tree = juce::ValueTree::readFromData (data, (size_t) sizeInBytes);
    if (tree.isValid())
        apvts.replaceState (tree);
}

//==============================================================================
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new PitchCorrectAudioProcessor();
}
