#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>
#include "PitchDetector.h"
#include "ScaleQuantizer.h"
#include "PitchShifter.h"

namespace ParamIDs
{
    static const juce::String key           = "KEY";
    static const juce::String scale         = "SCALE";
    static const juce::String retuneSpeed   = "RETUNE_SPEED";
    static const juce::String humanize      = "HUMANIZE";
    static const juce::String formantShift  = "FORMANT_SHIFT";
    static const juce::String air           = "AIR";
    static const juce::String mix           = "MIX";
}

class PitchCorrectAudioProcessor : public juce::AudioProcessor
{
public:
    PitchCorrectAudioProcessor();
    ~PitchCorrectAudioProcessor() override;

    //==============================================================================
    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    //==============================================================================
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    //==============================================================================
    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override  { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    //==============================================================================
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    //==============================================================================
    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    juce::AudioProcessorValueTreeState apvts;

    // --- Data the editor reads each frame for the pitch meter ---
    struct MeterState
    {
        std::atomic<float> detectedFreqHz { 0.0f };
        std::atomic<float> targetFreqHz   { 0.0f };
        std::atomic<bool>  voiced         { false };
    };
    MeterState meterState;

private:
    void updateAirFilterCoefficients (float airAmount01);

    PitchDetector pitchDetector;
    ScaleQuantizer scaleQuantizer;
    PitchShifter pitchShifter;

    // "Air" enhancement: a subtle high shelf (~10-12kHz) applied to the
    // wet (pitch-corrected) signal only, giving a bit of the crisp,
    // polished top-end characteristic of modern trap vocal chains
    // without simply boosting the dry track's existing sibilance.
    //
    // RT-safety: airCoefficients is allocated exactly ONCE, in
    // prepareToPlay(), via juce::dsp::IIR::Coefficients<float>::makeHighShelf().
    // Both channel filters hold a reference to that *same* Ptr (assigned,
    // never copied). Every subsequent update (including every call from
    // processBlock) mutates the existing coefficient array's 5 floats
    // in place -- see updateAirFilterCoefficients()'s definition -- so no
    // heap allocation ever occurs on the audio thread, even though the
    // shelf gain continues to track the smoothed "Air" parameter sample-
    // accurately.
    static constexpr int maxAirChannels = 2;
    std::array<juce::dsp::IIR::Filter<float>, maxAirChannels> airFilter;
    juce::dsp::IIR::Coefficients<float>::Ptr airCoefficients;
    juce::SmoothedValue<float> airAmountSmoothed;
    float lastAppliedAirAmount01 = -1.0f; // sentinel so the first block always computes coefficients

    juce::AudioBuffer<float> wetBuffer;
    juce::AudioBuffer<float> monoAnalysisBuffer;

    double currentSampleRate = 44100.0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (PitchCorrectAudioProcessor)
};
