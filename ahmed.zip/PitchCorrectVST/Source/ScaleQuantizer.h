#pragma once
#include <array>
#include <cmath>

/**
    ScaleQuantizer
    --------------
    Pure, stateless(-ish) music theory helper: given a detected frequency,
    a root key, and a scale, finds the nearest in-scale MIDI note and its
    target frequency using equal temperament (A4 = 440Hz):

        f = 440 * 2^((midi - 69) / 12)
*/
class ScaleQuantizer
{
public:
    enum class Key
    {
        C = 0, Cs, D, Ds, E, F, Fs, G, Gs, A, As, B, Count
    };

    enum class Scale
    {
        Major = 0, NaturalMinor, Chromatic, Count
    };

    static const char* getKeyName (Key k)
    {
        static const char* names[] = { "C", "C#", "D", "D#", "E", "F",
                                        "F#", "G", "G#", "A", "A#", "B" };
        return names[(int) k];
    }

    static const char* getScaleName (Scale s)
    {
        switch (s)
        {
            case Scale::Major:        return "Major";
            case Scale::NaturalMinor: return "Natural Minor";
            case Scale::Chromatic:    return "Chromatic";
            default:                  return "?";
        }
    }

    void setKey (Key k) noexcept     { currentKey = k; }
    void setScale (Scale s) noexcept { currentScale = s; }

    Key getKey() const noexcept      { return currentKey; }
    Scale getScale() const noexcept  { return currentScale; }

    /** Converts a frequency in Hz to the nearest (fractional) MIDI note number. */
    static double freqToMidi (double freqHz) noexcept
    {
        return 69.0 + 12.0 * std::log2 (freqHz / 440.0);
    }

    /** Converts a MIDI note number (may be fractional) to a frequency in Hz. */
    static double midiToFreq (double midiNote) noexcept
    {
        return 440.0 * std::pow (2.0, (midiNote - 69.0) / 12.0);
    }

    /**
        Given an input frequency, returns the frequency of the nearest note
        that belongs to the currently configured key + scale.

        `humanizeAmount` in [0, 1]: when > 0, notes within a small deviation
        band around the target are left un-quantized (or partially
        quantized) so natural vibrato/expression is preserved rather than
        being flattened onto a dead-flat pitch line. This mirrors
        Auto-Tune's "Humanize"/Flex-Tune behaviour.
    */
    double quantizeFrequency (double inputFreqHz, float humanizeAmount = 0.0f) const noexcept
    {
        if (inputFreqHz <= 0.0)
            return inputFreqHz;

        const double inputMidi = freqToMidi (inputFreqHz);
        const double nearestMidi = findNearestScaleMidiNote (inputMidi);

        if (humanizeAmount <= 0.0f)
            return midiToFreq (nearestMidi);

        // Humanize: the further the input already is from the target
        // relative to a semitone, within a deviation window scaled by
        // humanizeAmount, the less hard we snap it — this lets small,
        // fast vibrato deviations ride through un-flattened while still
        // correcting genuinely off-pitch notes.
        const double deviationSemitones = inputMidi - nearestMidi; // signed, in [-0.5, 0.5] typically
        const double toleranceWindow = 0.5 * (double) humanizeAmount; // up to +/- 0.5 semitone at 100%

        if (std::abs (deviationSemitones) <= toleranceWindow)
            return inputFreqHz; // within the natural-vibrato window: don't touch it

        // Otherwise pull back toward the scale note, but only cross the
        // tolerance boundary rather than snapping the full distance.
        const double sign = deviationSemitones < 0.0 ? -1.0 : 1.0;
        const double correctedMidi = nearestMidi + sign * toleranceWindow;
        return midiToFreq (correctedMidi);
    }

    /** Returns the semitone offsets (0-11) that belong to the current scale,
        relative to the root key at position 0. */
    std::array<int, 12> getScaleIntervals() const noexcept
    {
        // 1 = note in scale, 0 = not. Index 0 = root.
        static const std::array<int, 12> major     = { 1,0,1,0,1,1,0,1,0,1,0,1 };
        static const std::array<int, 12> naturalMin= { 1,0,1,1,0,1,0,1,1,0,1,0 };
        static const std::array<int, 12> chromatic = { 1,1,1,1,1,1,1,1,1,1,1,1 };

        switch (currentScale)
        {
            case Scale::Major:        return major;
            case Scale::NaturalMinor: return naturalMin;
            default:                  return chromatic;
        }
    }

private:
    double findNearestScaleMidiNote (double inputMidi) const noexcept
    {
        const int baseNote = (int) std::floor (inputMidi + 0.5); // nearest integer MIDI note
        const auto intervals = getScaleIntervals();
        const int rootOffset = (int) currentKey;

        // Search outward from baseNote for the closest MIDI note whose
        // pitch class is in the active scale.
        for (int distance = 0; distance <= 12; ++distance)
        {
            for (int dir = -1; dir <= 1; dir += 2)
            {
                if (distance == 0 && dir == 1) continue; // avoid checking 0 twice
                const int candidate = baseNote + dir * distance;
                const int pitchClass = ((candidate - rootOffset) % 12 + 12) % 12;
                if (intervals[(size_t) pitchClass] == 1)
                    return (double) candidate;
            }
        }
        return (double) baseNote; // chromatic fallback, should not be reached
    }

    Key currentKey = Key::C;
    Scale currentScale = Scale::Major;
};
